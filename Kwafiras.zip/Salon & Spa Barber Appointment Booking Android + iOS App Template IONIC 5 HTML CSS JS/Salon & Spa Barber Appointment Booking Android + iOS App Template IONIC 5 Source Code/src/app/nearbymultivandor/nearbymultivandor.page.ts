import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nearbymultivandor',
  templateUrl: './nearbymultivandor.page.html',
  styleUrls: ['./nearbymultivandor.page.scss'],
})
export class NearbymultivandorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
