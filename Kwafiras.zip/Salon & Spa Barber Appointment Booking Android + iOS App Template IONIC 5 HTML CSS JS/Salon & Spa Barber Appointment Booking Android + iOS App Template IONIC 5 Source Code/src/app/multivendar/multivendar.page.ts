import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multivendar',
  templateUrl: './multivendar.page.html',
  styleUrls: ['./multivendar.page.scss'],
})
export class MultivendarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
